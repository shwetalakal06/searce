---
layout: page
title: SEARCE
permalink: /searce/
---

<img src="/img/Searce1.jpg" id="banner_image">
<div id="bg-img">
<h1 style="font-weight: 300;font-family:open sans;font-size: 36px;line-height: 46px;color:#fff;" id="inner_text">You know what???<br>We actually help you transform business!!!</h1><br>

</div>










<div id="searce_sec1">


<h2 style="font-size: 25px;text-align: center;color:#ffffff;font-weight:300;padding-top: 80px;margin-top: 84px;">We create engaging software products, improve business processes & deliver high performance outcomes.</h2>
<p style="font-size:14px;color:#fff;    font-size: 14px;color: #fff;text-align: center;padding-right: 629px;line-height: 1.66em;margin-left: 607px;">With a strong belief that Best Practices are Overrated, Searce assembles a small, highly empowered team of top performing engineers and geeks who work to identify better ways of doing things. The innovation focused work culture ensures that the team is encouraged to make mistakes and question the status quo in order to improve processes and deliver transformation.</p>

</div>

<div id="searce_sec2" >
<img src="/img/mix.png" id="mix_img">

<div id="list_sec">
<ul id="lis">
<li>40+% Engineers; 20+% Computer Science graduates; 25+% MBA/Masters; 99+% Graduates</li>
<li>Co-sourcing: Customer Partnership Delivery Model</li>
<li>Value Driven Pricing</li>
<li>Culture of straight talk = No bullshit + Ability to accept mistakes & the courage to ask the right questions.</li>
</ul>
</div>

<div class="searce_row">

<div class="searce_col">
<img src="/img/OurBelifs.jpg" style="margin-left:441px;padding-top: 156px;">
<ul id="searce_list2">
<li>Best practices are overrated.</li>
<li>Ideate, Innovate, Improve and repeat. No sacred cows.</li>
</ul>
</div>
<div class="searce_col">
<img src="/img/Values.jpg" style="margin-left:681px;padding-top: 156px;">
<ul id="searce_list21">
<li>We do what we say and say what we do.</li>
<li>Improve things with passion.</li>
</ul>
</div>

<div class="searce_col">
<img src="/img/Ownership.jpg" style="margin-left:926px;padding-top: 156px;">
<ul id="searce_list23">
<li>Driven. Self-motivated. Self-governing teams and individuals.</li>
<li>Mistakes are encouraged, creativity is rewarded and enthusiasm is forever welcome.</li>
</ul>
</div>

<div class="searce_col">
<img src="/img/Innovation.jpg" style="margin-left:1167px;padding-top: 156px;">
<ul id="list24">
<li>Smaller Teams, Ideas unlimited, Greater Ownership, Faster Delivery & Happier Outcomes.</li>

</ul>
</div>

</div>
</div>






